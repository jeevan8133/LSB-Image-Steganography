/*
Name:JEEVAN N M
Date:28-10-2023
Description:Steganography
Input:./a.out -e beautiful.bmp secret.txt
Output:encoding
Read and validate encode arguments is success
<------Started Encoding------>
INFO: ## Encoding Procedure Started ##
INFO: Open Files: Success
width = 1024
height = 768
INFO: check_capacity SUCCESS
INFO: Copy_bmp_header SUCCESS
INFO: MAGIC STRING encoded
INFO: Secret File Extension size encoded
INFO: Secret File extension encoded
INFO: Secret File size encoded
INFO: Secret File data encoded
INFO: Remaining Image has been copied
<<--------Completed Encoding-------->>
*/
#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include <string.h>

/* Main Encoding Function*/
char* ext;
Status do_encoding( EncodeInfo *encInfo)
{
    int ret = open_files(encInfo);
    if(ret == e_success)
    {
        printf("INFO: ## Encoding Procedure Started ##\n");
        printf("INFO: Open Files: Success\n");
        /*Check whether Source Image File has sufficient capacity to hold the data*/
        if(!check_capacity(encInfo))
        {
            printf("INFO: check_capacity SUCCESS\n");

            /*Copy src image header content to stego file*/
            if(!copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image))
            {
                printf("INFO: Copy_bmp_header SUCCESS\n");

                /*Encode Magic String into the stego File*/
                if(!encode_magic_string(MAGIC_STRING, encInfo))
                {
                    printf("INFO: MAGIC STRING encoded\n");
                    ext = strstr(encInfo->secret_fname, ".");
                    ret = encode_secretfile_extn_size(strlen(ext), encInfo->fptr_src_image, encInfo->fptr_stego_image);

                    /* Encode Secret file extn size*/
                    if(ret == e_success)
                    {
                        printf("INFO: Secret File Extension size encoded\n");

                        /* Encode Secret file extn*/
                        if(!encode_secret_file_extn(ext, encInfo))
                        {
                            printf("INFO: Secret File extension encoded\n");

                            /* Encode secret file size*/
                            if(!encode_secret_file_size(encInfo->size_secret_file,encInfo))
                            {
                                printf("INFO: Secret File size encoded\n");

                                /*Encode secret file data*/
                                if(!encode_secret_file_data(encInfo))
                                {
                                    printf("INFO: Secret File data encoded\n");

                                    /* Copy Remaining data from the src image to stego image*/
                                    if(!copy_remaining_img_data( encInfo->fptr_src_image, encInfo->fptr_stego_image))
                                    {
                                        printf("INFO: Remaining Image has been copied\n");
                                         return e_success;
                                        printf("INFO: ## Encoding Done Successfully ##\n");
                                    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
}

Status read_and_validate_encode_args(char*argv[], EncodeInfo *encInfo)
{

        if(strcmp(strstr(argv[2],"."),".bmp")==0)
        {
                encInfo->src_image_fname = argv[2];
        }

        if(strcmp(strstr(argv[3],"."),".txt")==0 || strcmp(strstr(argv[3],"."),".c")==0)
        {
                encInfo->secret_fname = argv[3];
        }
        else
                return e_failure;

        if(argv[4] != NULL)
        {
                encInfo->stego_image_fname = argv[4];
        }
        else
        {
                encInfo->stego_image_fname = "default.bmp";
        }

        return e_success;
}

OperationType check_operation_type(char *argv[])
{
        if(argv[1] != NULL)
        {
                if (!strcmp(argv[1], "-e"))
                {
                        return e_encode;
                }
                else if(!strcmp(argv[1], "-d"))
                {
                        return e_decode;
                }
                else
                {
                        return e_unsupported;
                }
        }
        return e_unsupported;
}

Status copy_bmp_header(FILE* fptr_src_image, FILE* fptr_dest_image)
{
        fseek(fptr_src_image, 0L, SEEK_SET);
        char arr[54];
        fread(arr, 54, 1, fptr_src_image);
        fwrite(arr, 54, 1, fptr_dest_image);
        return e_success;
}

uint get_file_size(FILE*secret)
{
        fseek(secret, 0L, SEEK_END);
        return ftell(secret);
}

Status check_capacity(EncodeInfo *encInfo)
{


        encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
        encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);
        int magic_string = strlen(MAGIC_STRING);
        int ext_length = strlen(encInfo->extn_secret_file);

        //long total_bytes = 54 + magic_string * 8 + ext_length * 8 + sizeof(int) * 8 + encInfo-> size_secret_file * 8;
        int total_bytes = 54 + magic_string * 8 + ext_length * 8 + sizeof(int) * 8 + encInfo-> size_secret_file * 8;

        if(encInfo->image_capacity >= total_bytes)
                return e_success;
        else
                return e_failure;
}

Status encode_data_to_image(const char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
        char image_buffer[8];
        for(int i = 0; i < size; i++)
        {
                fread(image_buffer,8,1,fptr_src_image);
                encode_byte_to_lsb(data[i],image_buffer);
                fwrite(image_buffer,8,1,fptr_stego_image);
        }
        return e_success;
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
        unsigned char mask = 0x80;
        for(int i = 0; i < 8; i++)
        {
                image_buffer[i] = image_buffer[i] & 0xFE;
                if(data  & mask)
                        image_buffer[i] |= 1;
                mask = mask>>1;
        }
}


Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
        encode_data_to_image(magic_string,strlen(magic_string),encInfo->fptr_src_image,encInfo->fptr_stego_image);
        return e_success;
}




Status encode_secret_file_extn(const char* data, EncodeInfo *encInfo)
{
    encode_data_to_image(data, strlen(data), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}


Status encode_secret_file_size(int size, EncodeInfo *encInfo)
{
    char buff[32];
    fread(buff, 32, 1, encInfo->fptr_src_image);
    encode_size_to_lsb(size, buff);
    fwrite(buff, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}

Status encode_size_to_lsb( int size , char *image_buffer )
{
        unsigned int mask = 0x80000000;
        for(int i = 0; i < 32; i++)
        {
                image_buffer[i] &= 0xFFFFFFFE;
                if(size  & mask)
                        image_buffer[i] |= 1;
                mask = mask>>1;
        }

}
Status encode_secretfile_extn_size(int size, FILE* fptr_src_image, FILE* fptr_stego_image)
{
    char buff[32];
    fread(buff, 32, 1, fptr_src_image);
    encode_size_to_lsb(size, buff);
    fwrite(buff, 32, 1, fptr_stego_image);
    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char buff[8];
    char data;
    rewind(encInfo->fptr_secret);
    while ((data = fgetc(encInfo->fptr_secret)) != EOF)
    {
        fread(buff, 8, 1, encInfo->fptr_src_image);
        encode_byte_to_lsb(data, buff);
        fwrite(buff, 8, 1, encInfo->fptr_stego_image);
    }

    return e_success;
}

Status copy_remaining_img_data( FILE *fptr_src , FILE *fptr_dest )
{
    char ch ;
    while ( ( fread ( &ch , 1 , 1 , fptr_src)) > 0 )
    {
        fwrite ( &ch , 1 , 1 , fptr_dest );
    }
    return e_success ;
}

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
